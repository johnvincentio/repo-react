This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app) and Rescripts.

You can:

- [Open this example in a new CodeSandbox](https://codesandbox.io/s/github/tannerlinsley/react-table/tree/master/examples/column-resizing)
- `yarn` and `yarn start` to run and edit the example
